LOW LYFE KUSTOMS APP — STARTER VERSION

This is a free Progressive Web App (PWA). It can be installed on iPhone and Android from a web link.

NEXT STEP:
1. Create a free GitHub account if you don't have one.
2. Create a repository named low-lyfe-kustoms-app.
3. Upload every file in this folder.
4. Turn on GitHub Pages.
5. Open the Pages link on a phone and use Add to Home Screen / Install App.

The app is intentionally simple so we can add the real club content next:
- official logo
- Facebook/Instagram links
- events and flyers
- member ride submissions
- photo gallery
- officer/member area
- announcements
